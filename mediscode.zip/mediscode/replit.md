# Medis Patent Extractor v1.0

## Overview
A Flask web application that extracts pharmaceutical patent information from multiple authoritative sources, with intelligent RLD (Reference Listed Drug) prioritization and comprehensive search capabilities.

## Project Type
Flask web application (Python 3.11)

## Key Features

### 🎯 Core Functionality
- **Multi-source patent search**: Searches USPTO PatentsView, FDA Orange Book, and Lens.org (with API key)
- **Intelligent drug name resolution**: Automatically converts brand names to active ingredients using RxNorm API
- **RLD patent prioritization**: Identifies and highlights Reference Listed Drug patents from FDA Orange Book
- **Comprehensive search**: Searches for both RLD and generic patents, displaying RLD patents first
- **Direct PDF downloads**: One-click download links for patent PDFs from USPTO and Lens.org
- **Excel export**: Download all search results as a spreadsheet

### 🎨 User Interface
- **Loading modal**: Animated spinner appears during search with informative status messages
- **RLD/Generic badges**: Clear visual indicators for patent type
- **Color-coded sources**: Lens (blue), USPTO (primary), Orange Book (dark)
- **Highlighted RLD rows**: RLD patents have yellow background for easy identification
- **Responsive design**: Works seamlessly on desktop, tablet, and mobile devices
- **Modern styling**: Bootstrap 5 with custom enhancements

### 🔍 Search Intelligence
- Searches by both brand names (e.g., "Glucophage") and INN (e.g., "Metformin")
- Queries Orange Book using both Product and Ingredient parameters
- Resolves drug names to active ingredients automatically
- Deduplicates search terms to optimize API calls
- Increased pagination for comprehensive results (100-200+ patents per search)

## Architecture

### Backend (Flask)
- **app.py**: Main Flask application with routes
  - `/` - Search form and results display
  - `/download` - Excel file generation
- **rld_extractor.py**: Core extraction logic
  - RLD patent detection from FDA Orange Book
  - Multi-source patent aggregation
  - PDF URL generation
  - Result prioritization and sorting

### Frontend (Jinja2 Templates)
- **templates/base.html**: Base layout with navigation and footer
- **templates/index.html**: Search interface with loading modal and results table

### Data Flow
1. User enters drug name (brand or INN)
2. System resolves to ingredients using RxNorm
3. Searches FDA Orange Book for RLD patents (by both Product and Ingredient)
4. Queries USPTO PatentsView and Lens.org with ingredient names
5. Flags each patent as RLD or Generic
6. Sorts results to prioritize RLD patents
7. Displays with badges, highlighting, and PDF download links

## API Integrations
- **RxNorm API**: Drug name resolution to ingredients
- **FDA Orange Book**: RLD patent identification
- **USPTO PatentsView**: US patent database search
- **Lens.org API** (optional): International patent database

## PDF Download URLs
- **USPTO Patents**: `https://pdfpiw.uspto.gov/.piw?docid={number}`
- **Lens Patents**: `https://link.lens.org/{number}/fulltext.pdf`

## Configuration
- Server binds to `0.0.0.0:5000` for Replit environment
- Debug mode enabled for development
- Production deployment configured with Gunicorn

## Dependencies
See `requirements.txt` for full list:
- flask - Web framework
- requests - HTTP library
- beautifulsoup4 - HTML parsing
- pandas - Data manipulation
- openpyxl - Excel export
- python-dateutil - Date parsing
- gunicorn - Production WSGI server

## Recent Changes (Oct 24, 2025)

### Version 1.0 Enhancements
- **Renamed** from "RLD Patent Extractor" to "Medis Patent Extractor v1.0"
- **Added loading modal** with spinner animation during searches
- **Implemented RLD detection** with FDA Orange Book integration
- **Added PDF download links** for all patents
- **Enhanced search** to work with both brand and INN queries
- **Improved UI** with RLD/Generic badges and color-coded highlighting
- **Optimized queries** with search term deduplication
- **Increased search depth** for more comprehensive results
- **Fixed critical bug** where INN searches weren't detecting RLD patents

### Initial Setup (Oct 24, 2025)
- Imported project from GitHub
- Renamed `.txt` files to proper `.py` extensions
- Updated Flask configuration for Replit proxy compatibility
- Installed all Python dependencies
- Created `.gitignore` for Python project
- Configured workflow and deployment settings

## User Preferences
None documented yet.

## Notes
- The Lens.org API key is optional; without it, results come from USPTO and Orange Book only
- RLD detection works for both proprietary drug names and international nonproprietary names
- Patent expiry dates are estimated as publication date + 20 years
- The application handles API failures gracefully and continues with available sources
