from flask import Flask, render_template, request, send_file
import io
from rld_extractor import run_extraction

app = Flask(__name__)
last_df = None

@app.route("/", methods=["GET", "POST"])
def index():
    global last_df
    results = None
    query = ""
    error_msg = None
    
    if request.method == "POST":
        query = request.form.get("query", "").strip()
        lens_key = request.form.get("lens_key", "").strip() or None
        
        if not query:
            error_msg = "Please enter a drug name or INN."
        else:
            try:
                df = run_extraction(query, lens_key)
                if df is None or df.empty:
                    error_msg = "No patents found. Try another name or add your Lens.org API key."
                else:
                    results = df.to_dict(orient="records")
                    last_df = df
            except Exception as e:
                error_msg = f"Error while searching: {str(e)}"
    
    return render_template("index.html", results=results, query=query, error_msg=error_msg)

@app.route("/download")
def download():
    global last_df
    if last_df is None:
        return "No data to download", 400
    
    buf = io.BytesIO()
    last_df.to_excel(buf, index=False)
    buf.seek(0)
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="rld_patents.xlsx"
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
