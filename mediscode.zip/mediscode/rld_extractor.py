import requests
import time
import json
import re
from datetime import timedelta
from dateutil.parser import parse as parse_date
from bs4 import BeautifulSoup
import pandas as pd

USER_AGENT = "medis-patent-extractor/1.0"
REQUEST_SLEEP = 0.4

def normalize_text(s):
    if not s:
        return ""
    return re.sub(r"\s+", " ", str(s).strip())

def safe_get(url, params=None, headers=None, method="GET", data=None, max_tries=3, timeout=30):
    headers = headers or {}
    headers.setdefault("User-Agent", USER_AGENT)
    
    for i in range(max_tries):
        try:
            if method == "GET":
                r = requests.get(url, params=params, headers=headers, timeout=timeout)
            else:
                r = requests.post(url, json=data, headers=headers, timeout=timeout)
            r.raise_for_status()
            return r
        except Exception:
            time.sleep(1 + i)
    
    raise RuntimeError(f"Failed to access {url}")

def get_patent_pdf_url(publication_number, source):
    if not publication_number:
        return None
    
    patent_num = str(publication_number).strip()
    
    if source == "USPTO":
        clean_num = re.sub(r'[^0-9]', '', patent_num)
        if clean_num:
            return f"https://pdfpiw.uspto.gov/.piw?docid={clean_num}"
    
    elif source == "Lens":
        return f"https://link.lens.org/{patent_num}/fulltext.pdf"
    
    return None

def resolve_to_ingredients(query):
    q = query.strip()
    try:
        url = f"https://rxnav.nlm.nih.gov/REST/rxcui.json?name={requests.utils.quote(q)}"
        r = safe_get(url)
        j = r.json()
        rxcui = j.get("idGroup", {}).get("rxnormId", [None])[0]
        
        if rxcui:
            url2 = f"https://rxnav.nlm.nih.gov/REST/rxcui/{rxcui}/related.json?tty=SCDC+SCD+IN"
            j2 = safe_get(url2).json()
            names = set()
            for g in j2.get("relatedGroup", {}).get("conceptGroup", []):
                for c in g.get("conceptProperties", []):
                    if c.get("name"):
                        names.add(c["name"])
            if names:
                return list(names)
    except Exception:
        pass
    return [q]

def get_rld_patents_from_orange_book(search_terms):
    rld_patents = set()
    url = "https://www.accessdata.fda.gov/scripts/cder/ob/search.cfm"
    
    if isinstance(search_terms, str):
        search_terms = [search_terms]
    
    for term in search_terms:
        try:
            soup = BeautifulSoup(safe_get(url, params={"Product": term}).text, "html.parser")
            for tr in soup.select("tr"):
                txt = tr.get_text(" ", strip=True)
                if "Patent" in txt:
                    patent_matches = re.findall(r'\b\d{7,8}\b', txt)
                    for pm in patent_matches:
                        rld_patents.add(pm)
            time.sleep(REQUEST_SLEEP)
        except Exception:
            pass
        
        try:
            soup = BeautifulSoup(safe_get(url, params={"Ingredient": term}).text, "html.parser")
            for tr in soup.select("tr"):
                txt = tr.get_text(" ", strip=True)
                if "Patent" in txt:
                    patent_matches = re.findall(r'\b\d{7,8}\b', txt)
                    for pm in patent_matches:
                        rld_patents.add(pm)
            time.sleep(REQUEST_SLEEP)
        except Exception:
            pass
    
    return rld_patents

def search_lens(ingredient, api_key, rld_patents, pages=2):
    if not api_key:
        return []
    
    base = "https://api.lens.org/patents/search"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT
    }
    results = []
    
    try:
        for p in range(pages):
            body = {
                "query": {
                    "query_string": {
                        "query": f'"{ingredient}"',
                        "fields": ["title", "abstract", "description", "claims", "assignees"]
                    }
                },
                "size": 100,
                "from": p * 100
            }
            
            r = safe_get(base, method="POST", headers=headers, data=body, timeout=60)
            hits = r.json().get("data", [])
            
            for h in hits:
                pub_num = h.get("publication_number", "")
                clean_num = re.sub(r'[^0-9]', '', str(pub_num))
                is_rld = clean_num in rld_patents
                
                results.append({
                    "source": "Lens",
                    "title": normalize_text(h.get("title")),
                    "publication_number": pub_num,
                    "assignees": h.get("assignees"),
                    "publication_date": h.get("publication_date"),
                    "family_id": h.get("family_id"),
                    "estimated_expiry": estimate_expiry(h),
                    "is_rld": is_rld,
                    "pdf_url": get_patent_pdf_url(pub_num, "Lens")
                })
            
            time.sleep(REQUEST_SLEEP)
    except Exception:
        pass
    
    return results

def search_patentsview(ingredient, rld_patents, pages=3):
    base = "https://api.patentsview.org/patents/query"
    results = []
    
    for p in range(pages):
        q = {"_text_any": {"patent_title": ingredient, "patent_abstract": ingredient}}
        params = {
            "q": json.dumps(q),
            "f": json.dumps(["patent_number", "patent_title", "patent_date", "assignee_organization"]),
            "o": json.dumps({"page": p + 1, "per_page": 100})
        }
        
        try:
            j = safe_get(base, params=params).json()
        except Exception:
            break
        
        for pat in j.get("patents", []):
            pub_num = pat.get("patent_number", "")
            clean_num = re.sub(r'[^0-9]', '', str(pub_num))
            is_rld = clean_num in rld_patents
            
            results.append({
                "source": "USPTO",
                "title": normalize_text(pat.get("patent_title")),
                "publication_number": pub_num,
                "assignees": [a.get("assignee_organization") for a in pat.get("assignees", []) if a.get("assignee_organization")],
                "publication_date": pat.get("patent_date"),
                "estimated_expiry": estimate_expiry(pat),
                "is_rld": is_rld,
                "pdf_url": get_patent_pdf_url(pub_num, "USPTO")
            })
        
        time.sleep(REQUEST_SLEEP)
    
    return results

def orange_book_lookup(brand, rld_patents):
    try:
        url = "https://www.accessdata.fda.gov/scripts/cder/ob/search.cfm"
        soup = BeautifulSoup(safe_get(url, params={"Product": brand}).text, "html.parser")
        hits = []
        
        for tr in soup.select("tr"):
            txt = tr.get_text(" ", strip=True)
            if "Patent" in txt or "Expiration" in txt:
                patent_nums = re.findall(r'\b(\d{7,8})\b', txt)
                is_rld = any(pn in rld_patents for pn in patent_nums)
                
                hits.append({
                    "source": "Orange Book",
                    "title": txt,
                    "publication_number": patent_nums[0] if patent_nums else None,
                    "assignees": None,
                    "publication_date": None,
                    "estimated_expiry": None,
                    "is_rld": is_rld,
                    "pdf_url": get_patent_pdf_url(patent_nums[0], "USPTO") if patent_nums else None
                })
        
        return hits
    except Exception:
        return []

def estimate_expiry(entry):
    try:
        date = entry.get("publication_date") or entry.get("patent_date")
        if date:
            d = parse_date(date)
            return (d.date() + timedelta(days=20 * 365)).isoformat()
    except Exception:
        pass
    return None

def run_extraction(query, lens_api_key=None):
    ingredients = resolve_to_ingredients(query)
    
    all_search_terms = list(set([query] + ingredients))
    rld_patents = get_rld_patents_from_orange_book(all_search_terms)
    
    all_hits = []
    
    for ing in ingredients:
        all_hits += search_lens(ing, lens_api_key, rld_patents, pages=2)
        all_hits += search_patentsview(ing, rld_patents, pages=3)
    
    all_hits += orange_book_lookup(query, rld_patents)
    
    df = pd.DataFrame(all_hits)
    
    if not df.empty:
        df['sort_priority'] = df['is_rld'].apply(lambda x: 0 if x else 1)
        df = df.sort_values('sort_priority').drop('sort_priority', axis=1)
        df = df.reset_index(drop=True)
    
    return df
