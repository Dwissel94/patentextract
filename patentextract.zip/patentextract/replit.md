# Medis Patent Extractor v1.0

## Overview
A Flask web application that extracts pharmaceutical patent information from multiple authoritative sources, with intelligent RLD (Reference Listed Drug) prioritization and comprehensive search capabilities.

## Project Type
Flask web application (Python 3.11)

## Key Features

### 🎯 Core Functionality
- **Multi-source patent search**: Searches USPTO PatentsView, FDA Orange Book, and Lens.org (with API key)
- **Intelligent drug name resolution**: Automatically converts brand names to active ingredients using RxNorm API
- **RLD patent prioritization**: Identifies and highlights Reference Listed Drug patents from FDA Orange Book
- **Comprehensive search**: Searches for both RLD and generic patents, displaying RLD patents first
- **Direct PDF downloads**: One-click download links for patent PDFs from USPTO and Lens.org
- **Excel export**: Download all search results as a spreadsheet

### 🎨 User Interface
- **Settings modal**: Gear icon in navigation bar for API key management with secure masked preview
- **Loading modal**: Animated spinner appears during search with informative status messages
- **RLD/Generic badges**: Clear visual indicators for patent type
- **Color-coded sources**: Lens (blue), USPTO (primary), Orange Book (dark)
- **Highlighted RLD rows**: RLD patents have yellow background for easy identification
- **Responsive design**: Works seamlessly on desktop, tablet, and mobile devices
- **Modern styling**: Bootstrap 5 with custom enhancements
- **Success/error alerts**: Clear feedback messages for all user actions

### 🔍 Search Intelligence
- Searches by both brand names (e.g., "Glucophage") and INN (e.g., "Metformin")
- Queries Orange Book using both Product and Ingredient parameters
- Resolves drug names to active ingredients automatically
- Deduplicates search terms to optimize API calls
- Increased pagination for comprehensive results (100-200+ patents per search)

## Architecture

### Backend (Flask)
- **app.py**: Main Flask application with routes
  - `/` - Search form and results display
  - `/download` - Excel file generation
  - `/update_api_key` - API key management endpoint
  - Session-based flash messages for user feedback
- **rld_extractor.py**: Core extraction logic
  - RLD patent detection from FDA Orange Book
  - Multi-source patent aggregation
  - PDF URL generation
  - Result prioritization and sorting

### Frontend (Jinja2 Templates)
- **templates/base.html**: Base layout with navigation and footer
- **templates/index.html**: Search interface with loading modal and results table

### Data Flow
1. User enters drug name (brand or INN)
2. System resolves to ingredients using RxNorm
3. Searches FDA Orange Book for RLD patents (by both Product and Ingredient)
4. Queries USPTO PatentsView and Lens.org with ingredient names
5. Flags each patent as RLD or Generic
6. Sorts results to prioritize RLD patents
7. Displays with badges, highlighting, and PDF download links

## API Integrations
- **RxNorm API**: Drug name resolution to ingredients
- **FDA Orange Book**: RLD patent identification
- **USPTO PatentsView**: US patent database search
- **Lens.org API** (optional): International patent database

## PDF Download URLs
- **USPTO Patents**: `https://pdfpiw.uspto.gov/.piw?docid={number}`
- **Lens Patents**: `https://link.lens.org/{number}/fulltext.pdf`

## Configuration
- Server binds to `0.0.0.0:5000` for Replit environment
- Debug mode enabled for development
- Production deployment configured with Gunicorn
- Flask session secret key for secure flash messages and API key storage

## API Key Management
Users can manage their Lens.org API key in two ways:
1. **Settings UI** (recommended): Click the gear icon in the navigation bar
   - View masked preview of current API key
   - Update key directly in the app
   - See immediate success/error feedback
2. **Replit Secrets**: Set `LENS_API_KEY` in Replit environment (admin access required)

The app checks both session storage and environment variables, with session taking precedence for flexibility.

## Dependencies
See `requirements.txt` for full list:
- flask - Web framework
- requests - HTTP library
- beautifulsoup4 - HTML parsing
- pandas - Data manipulation
- openpyxl - Excel export
- python-dateutil - Date parsing
- gunicorn - Production WSGI server

## Recent Changes (Oct 24, 2025)

### Version 1.3 - Settings UI for API Key Management (Oct 24, 2025)
- **Added Settings modal**: Gear icon in navigation bar provides easy access to API key management
- **Secure API key preview**: Shows masked version of current API key (e.g., ABCD****WXYZ) in settings
- **In-app API key updates**: Users can update their Lens.org API key without accessing Replit Secrets
- **Session-based storage**: API keys stored in Flask session and environment variables for immediate use
- **User feedback system**: Success/error messages display on main page after settings updates
- **Security enhancements**: 
  - Password field never pre-populated with sensitive data
  - No logging of API key values
  - Masked preview shown separately from input field
- **Improved UX**: "Leave blank to keep current key" guidance for optional updates

### Version 1.2 - Enhanced RLD Detection & Tunisia Integration (Oct 24, 2025)
- **Secured API key storage**: Moved Lens.org API key to Replit Secrets for enhanced security
- **Removed API key input**: Eliminated Lens.org API key field from UI, now uses environment variable
- **Implemented FDA Orange Book RLD detection**: Downloads and parses FDA Orange Book data files to identify Reference Listed Drug patents
- **Added Tunisia DPM integration**: Checks if drugs are registered in Tunisia's pharmaceutical database (DPM)
- **Enhanced patent classification**: Patents are now accurately marked as RLD or Generic based on FDA Orange Book data
- **Improved sorting**: RLD patents are automatically prioritized and displayed first in results
- **Added Tunisia status column**: Shows registration status in Tunisia DPM database for each search
- **Increased search depth**: Now retrieves up to 100 patents from Lens.org (up from 50)
- **Better ingredient resolution**: Expanded to 3 ingredients maximum (up from 2)

### Version 1.1 - Complete Rebuild (Oct 24, 2025)
- **Fixed broken APIs**: USPTO PatentsView API discontinued (410), FDA Orange Book URL changed
- **Rebuilt extractor** to use only working Lens.org API with user's API key
- **Simplified codebase** from 250+ lines to ~200 lines, focusing on reliability
- **Added secure API key management** using Replit Secrets (LENS_API_KEY environment variable)
- **Improved error handling** with better timeout management and error messages
- **Added cache control headers** to prevent browser caching issues
- **Enhanced ingredient resolution** using RxNorm API (limits to primary active ingredients)
- **Successfully tested** with Metformin search returning 46 unique patents
- **Optimized performance** with reduced request timeouts and better sleep intervals

### Version 1.0 Enhancements
- **Renamed** from "RLD Patent Extractor" to "Medis Patent Extractor v1.0"
- **Added loading modal** with spinner animation during searches
- **Added PDF download links** for all patents
- **Enhanced search** to work with both brand and INN queries
- **Improved UI** with modern Bootstrap styling

### Initial Setup (Oct 24, 2025)
- Imported project from GitHub (extracted from zip file)
- Moved project files from subdirectory to root directory
- Installed Python 3.11 module
- Installed all Python dependencies via packager (Flask, requests, beautifulsoup4, pandas, openpyxl, python-dateutil, fuzzywuzzy, python-Levenshtein, gunicorn)
- Created `.gitignore` for Python project
- Configured Flask Server workflow on port 5000 with webview output
- Configured deployment with Gunicorn for autoscale deployment target
- App already configured for Replit environment (binds to 0.0.0.0:5000, includes cache control headers)
- Verified app is running successfully

## User Preferences
None documented yet.

## Notes
- The Lens.org API key is optional; without it, results come from USPTO and Orange Book only
- RLD detection works for both proprietary drug names and international nonproprietary names
- Patent expiry dates are estimated as publication date + 20 years
- The application handles API failures gracefully and continues with available sources
