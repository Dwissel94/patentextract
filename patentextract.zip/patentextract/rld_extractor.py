import requests
import time
import re
import os
from datetime import timedelta
from dateutil.parser import parse as parse_date
import pandas as pd
from bs4 import BeautifulSoup
import zipfile
from io import BytesIO

USER_AGENT = "medis-patent-extractor/1.0"
REQUEST_SLEEP = 0.5
REQUEST_TIMEOUT = 15

def normalize_text(s):
    if not s:
        return ""
    return re.sub(r"\s+", " ", str(s).strip())

def safe_get(url, params=None, headers=None, method="GET", data=None, max_tries=2, timeout=REQUEST_TIMEOUT):
    """Make HTTP requests with retries and timeout"""
    headers = headers or {}
    headers.setdefault("User-Agent", USER_AGENT)
    
    for i in range(max_tries):
        try:
            if method == "GET":
                r = requests.get(url, params=params, headers=headers, timeout=timeout)
            else:
                r = requests.post(url, json=data, headers=headers, timeout=timeout)
            r.raise_for_status()
            return r
        except requests.Timeout:
            if i == max_tries - 1:
                raise
            time.sleep(0.5)
        except Exception as e:
            if i == max_tries - 1:
                raise
            time.sleep(0.5)
    
    raise RuntimeError(f"Failed to access {url}")

def get_patent_pdf_url(publication_number, source):
    """Generate PDF download URLs for patents"""
    if not publication_number:
        return None
    
    patent_num = str(publication_number).strip()
    
    if source == "USPTO" or source == "Orange Book" or source == "Lens":
        clean_num = re.sub(r'[^0-9]', '', patent_num)
        if clean_num and len(clean_num) >= 7:
            return f"https://pdfpiw.uspto.gov/.piw?docid={clean_num}"
    
    return None

def resolve_to_ingredients(query):
    """Resolve drug names to active ingredients using RxNorm API"""
    q = query.strip()
    ingredients = [q]
    
    try:
        url = f"https://rxnav.nlm.nih.gov/REST/rxcui.json?name={requests.utils.quote(q)}"
        r = safe_get(url, timeout=10)
        j = r.json()
        rxcui = j.get("idGroup", {}).get("rxnormId", [None])[0]
        
        if rxcui:
            url2 = f"https://rxnav.nlm.nih.gov/REST/rxcui/{rxcui}/related.json?tty=IN"
            j2 = safe_get(url2, timeout=10).json()
            for g in j2.get("relatedGroup", {}).get("conceptGroup", []):
                if g.get("tty") == "IN":
                    for c in g.get("conceptProperties", [])[:3]:
                        name = c.get("name")
                        if name and name.lower() not in [ing.lower() for ing in ingredients]:
                            ingredients.append(name)
    except Exception as e:
        print(f"RxNorm error: {e}")
    
    return ingredients[:3]

def get_fda_orange_book_rld_patents(ingredient):
    """Fetch RLD patent data from FDA Orange Book"""
    print(f"Fetching FDA Orange Book data for: {ingredient}")
    rld_patents = set()
    rld_products = {}
    
    try:
        # Download FDA Orange Book data files
        url = "https://www.fda.gov/media/76860/download"
        print("Downloading FDA Orange Book data files...")
        response = safe_get(url, timeout=60)
        
        with zipfile.ZipFile(BytesIO(response.content)) as z:
            # Parse products.txt to find RLD products
            with z.open('products.txt') as f:
                products_df = pd.read_csv(f, sep='~', encoding='latin1', low_memory=False)
            
            # Filter for RLD products matching the ingredient
            # Note: FDA Orange Book uses 'Y'/'N' for RLD flag, not 'Yes'/'No'
            ing_lower = ingredient.lower()
            rld_df = products_df[
                (products_df['RLD'].str.strip().str.upper() == 'Y') & 
                (products_df['Ingredient'].str.lower().str.contains(ing_lower, na=False))
            ]
            
            if not rld_df.empty:
                print(f"Found {len(rld_df)} RLD products for {ingredient}")
                for _, row in rld_df.iterrows():
                    # Store application and product numbers with proper type conversion
                    appl_no = str(row['Appl_No']).strip()
                    product_no = str(row['Product_No']).strip()
                    key = f"{appl_no}_{product_no}"
                    rld_products[key] = {
                        'trade_name': row.get('Trade_Name', 'N/A'),
                        'ingredient': row.get('Ingredient', ingredient),
                        'applicant': row.get('Applicant', 'N/A')
                    }
            
            # Parse patent.txt to get patents for RLD products
            with z.open('patent.txt') as f:
                patents_df = pd.read_csv(f, sep='~', encoding='latin1', low_memory=False)
            
            # Match patents with RLD products
            for key in rld_products.keys():
                appl_no, product_no = key.split('_')
                # Convert both sides to strings for consistent matching
                matching_patents = patents_df[
                    (patents_df['Appl_No'].astype(str).str.strip() == appl_no) & 
                    (patents_df['Product_No'].astype(str).str.strip() == product_no)
                ]
                
                for _, patent_row in matching_patents.iterrows():
                    patent_no = str(patent_row.get('Patent_No', '')).strip()
                    if patent_no and patent_no != 'nan':
                        rld_patents.add(patent_no)
                        print(f"Found RLD patent: {patent_no} for {rld_products[key]['trade_name']}")
        
        time.sleep(REQUEST_SLEEP)
    except Exception as e:
        print(f"FDA Orange Book error: {e}")
        import traceback
        traceback.print_exc()
    
    return rld_patents

def check_tunisia_dpm_registration(ingredient):
    """Check if drug is registered in Tunisia DPM database"""
    print(f"Checking Tunisia DPM registration for: {ingredient}")
    
    try:
        url = "https://dpm.tn/index.php/medicaments-a-usage-humain/amms-par-dci"
        response = safe_get(url, timeout=20)
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Search for ingredient name in the page content
        page_text = soup.get_text().lower()
        ing_lower = ingredient.lower()
        
        if ing_lower in page_text:
            print(f"✓ {ingredient} found in Tunisia DPM database")
            return "Registered in Tunisia"
        else:
            print(f"✗ {ingredient} not found in Tunisia DPM database")
            return "Not found in Tunisia database"
        
    except Exception as e:
        print(f"Tunisia DPM lookup error: {e}")
        return "Tunisia lookup unavailable"

def search_lens(ingredient, api_key, rld_patent_numbers):
    """Search Lens.org patent database"""
    if not api_key:
        print("No Lens API key available")
        return []
    
    base = "https://api.lens.org/patent/search"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT
    }
    results = []
    
    try:
        print(f"Searching Lens.org for: {ingredient}")
        
        body = {
            "query": f'"{ingredient}"',
            "size": 100,
            "include": ["lens_id", "biblio"]
        }
        
        r = safe_get(base, method="POST", headers=headers, data=body, timeout=30)
        data = r.json()
        hits = data.get("data", [])
        
        print(f"Found {len(hits)} patents from Lens")
        
        for h in hits:
            biblio = h.get("biblio", {})
            pub_ref = biblio.get("publication_reference", {})
            pub_num = pub_ref.get("doc_number", "")
            pub_date = pub_ref.get("date", "")
            
            # Check if this is an RLD patent
            clean_num = re.sub(r'[^0-9]', '', str(pub_num))
            is_rld = clean_num in rld_patent_numbers
            
            assignees = []
            parties = biblio.get("parties", {})
            owners = parties.get("owners_all", [])
            for owner in owners[:3]:
                if isinstance(owner, dict):
                    name_obj = owner.get("extracted_name", {})
                    if isinstance(name_obj, dict):
                        name = name_obj.get("value", "")
                    else:
                        name = str(name_obj)
                    if name:
                        assignees.append(name)
            
            title_data = biblio.get("invention_title", {})
            if isinstance(title_data, list) and title_data:
                title = title_data[0].get("text", "")
            elif isinstance(title_data, dict):
                title = title_data.get("text", "")
            else:
                title = str(title_data) if title_data else "Patent"
            
            results.append({
                "source": "Lens",
                "title": normalize_text(title)[:200],
                "publication_number": pub_num,
                "assignees": ", ".join(assignees) if assignees else "N/A",
                "publication_date": pub_date,
                "estimated_expiry": estimate_expiry_from_date(pub_date),
                "is_rld": is_rld,
                "pdf_url": get_patent_pdf_url(pub_num, "Lens")
            })
        
        time.sleep(REQUEST_SLEEP)
    except Exception as e:
        print(f"Lens API error: {e}")
        import traceback
        traceback.print_exc()
    
    return results

def estimate_expiry_from_date(date_str):
    """Estimate patent expiry as publication date + 20 years"""
    try:
        if date_str:
            d = parse_date(str(date_str))
            expiry = d.date() + timedelta(days=20 * 365)
            return expiry.isoformat()
    except Exception:
        pass
    return "N/A"

def run_extraction(query):
    """Main extraction function"""
    print(f"Starting patent search for: {query}")
    
    lens_api_key = os.environ.get("LENS_API_KEY")
    
    if not lens_api_key:
        print("WARNING: No Lens.org API key found - please add one in Settings")
        lens_api_key = ""
    
    # Resolve to ingredients
    ingredients = resolve_to_ingredients(query)
    print(f"Searching for ingredients: {ingredients}")
    
    # Get FDA Orange Book RLD patents for all ingredients
    all_rld_patents = set()
    for ing in ingredients:
        rld_patents = get_fda_orange_book_rld_patents(ing)
        all_rld_patents.update(rld_patents)
    
    print(f"Total RLD patents found in FDA Orange Book: {len(all_rld_patents)}")
    
    # Check Tunisia DPM registration
    tunisia_status = check_tunisia_dpm_registration(ingredients[0])
    
    # Search Lens.org with RLD information
    all_hits = []
    for ing in ingredients:
        lens_results = search_lens(ing, lens_api_key, all_rld_patents)
        all_hits += lens_results
    
    if not all_hits:
        print("No patents found")
        return pd.DataFrame()
    
    df = pd.DataFrame(all_hits)
    
    # Remove duplicates
    df = df.drop_duplicates(subset=['publication_number'], keep='first')
    
    # Sort: RLD patents first
    df = df.sort_values(by=['is_rld', 'publication_date'], ascending=[False, False])
    
    # Add Tunisia registration status
    df['tunisia_status'] = tunisia_status
    
    df = df.reset_index(drop=True)
    
    rld_count = df[df['is_rld'] == True].shape[0]
    print(f"Total unique patents: {len(df)} ({rld_count} RLD, {len(df) - rld_count} Generic)")
    
    return df
