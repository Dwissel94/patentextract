import requests
import time
import re
import os
from datetime import timedelta
from dateutil.parser import parse as parse_date
import pandas as pd

USER_AGENT = "medis-patent-extractor/1.0"
REQUEST_SLEEP = 0.5
REQUEST_TIMEOUT = 15

def normalize_text(s):
    if not s:
        return ""
    return re.sub(r"\s+", " ", str(s).strip())

def safe_get(url, params=None, headers=None, method="GET", data=None, max_tries=2, timeout=REQUEST_TIMEOUT):
    """Make HTTP requests with retries and timeout"""
    headers = headers or {}
    headers.setdefault("User-Agent", USER_AGENT)
    
    for i in range(max_tries):
        try:
            if method == "GET":
                r = requests.get(url, params=params, headers=headers, timeout=timeout)
            else:
                r = requests.post(url, json=data, headers=headers, timeout=timeout)
            r.raise_for_status()
            return r
        except requests.Timeout:
            if i == max_tries - 1:
                raise
            time.sleep(0.5)
        except Exception as e:
            if i == max_tries - 1:
                raise
            time.sleep(0.5)
    
    raise RuntimeError(f"Failed to access {url}")

def get_patent_pdf_url(publication_number, source):
    """Generate PDF download URLs for patents"""
    if not publication_number:
        return None
    
    patent_num = str(publication_number).strip()
    
    if source == "USPTO" or source == "Orange Book" or source == "Lens":
        clean_num = re.sub(r'[^0-9]', '', patent_num)
        if clean_num and len(clean_num) >= 7:
            return f"https://pdfpiw.uspto.gov/.piw?docid={clean_num}"
    
    return None

def resolve_to_ingredients(query):
    """Resolve drug names to active ingredients using RxNorm API"""
    q = query.strip()
    ingredients = [q]
    
    try:
        url = f"https://rxnav.nlm.nih.gov/REST/rxcui.json?name={requests.utils.quote(q)}"
        r = safe_get(url, timeout=10)
        j = r.json()
        rxcui = j.get("idGroup", {}).get("rxnormId", [None])[0]
        
        if rxcui:
            url2 = f"https://rxnav.nlm.nih.gov/REST/rxcui/{rxcui}/related.json?tty=IN"
            j2 = safe_get(url2, timeout=10).json()
            for g in j2.get("relatedGroup", {}).get("conceptGroup", []):
                if g.get("tty") == "IN":
                    for c in g.get("conceptProperties", [])[:3]:
                        name = c.get("name")
                        if name and name.lower() not in [ing.lower() for ing in ingredients]:
                            ingredients.append(name)
    except Exception as e:
        print(f"RxNorm error: {e}")
    
    return ingredients[:2]

def search_lens(ingredient, api_key):
    """Search Lens.org patent database"""
    if not api_key:
        print("No Lens API key available")
        return []
    
    base = "https://api.lens.org/patent/search"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "User-Agent": USER_AGENT
    }
    results = []
    
    try:
        print(f"Searching Lens.org for: {ingredient}")
        
        body = {
            "query": f'"{ingredient}"',
            "size": 50,
            "include": ["lens_id", "biblio"]
        }
        
        r = safe_get(base, method="POST", headers=headers, data=body, timeout=30)
        data = r.json()
        hits = data.get("data", [])
        
        print(f"Found {len(hits)} patents from Lens")
        
        for h in hits:
            biblio = h.get("biblio", {})
            pub_ref = biblio.get("publication_reference", {})
            pub_num = pub_ref.get("doc_number", "")
            pub_date = pub_ref.get("date", "")
            
            assignees = []
            parties = biblio.get("parties", {})
            owners = parties.get("owners_all", [])
            for owner in owners[:3]:
                if isinstance(owner, dict):
                    name_obj = owner.get("extracted_name", {})
                    if isinstance(name_obj, dict):
                        name = name_obj.get("value", "")
                    else:
                        name = str(name_obj)
                    if name:
                        assignees.append(name)
            
            title_data = biblio.get("invention_title", {})
            if isinstance(title_data, list) and title_data:
                title = title_data[0].get("text", "")
            elif isinstance(title_data, dict):
                title = title_data.get("text", "")
            else:
                title = str(title_data) if title_data else "Patent"
            
            results.append({
                "source": "Lens",
                "title": normalize_text(title)[:200],
                "publication_number": pub_num,
                "assignees": ", ".join(assignees) if assignees else "N/A",
                "publication_date": pub_date,
                "estimated_expiry": estimate_expiry_from_date(pub_date),
                "is_rld": False,
                "pdf_url": get_patent_pdf_url(pub_num, "Lens")
            })
        
        time.sleep(REQUEST_SLEEP)
    except Exception as e:
        print(f"Lens API error: {e}")
        import traceback
        traceback.print_exc()
    
    return results

def estimate_expiry_from_date(date_str):
    """Estimate patent expiry as publication date + 20 years"""
    try:
        if date_str:
            d = parse_date(str(date_str))
            expiry = d.date() + timedelta(days=20 * 365)
            return expiry.isoformat()
    except Exception:
        pass
    return "N/A"

def run_extraction(query, lens_api_key=None):
    """Main extraction function"""
    print(f"Starting patent search for: {query}")
    
    if not lens_api_key:
        lens_api_key = os.environ.get("LENS_API_KEY")
    
    if not lens_api_key:
        print("ERROR: No Lens.org API key found")
        return pd.DataFrame()
    
    ingredients = resolve_to_ingredients(query)
    print(f"Searching for ingredients: {ingredients}")
    
    all_hits = []
    
    for ing in ingredients:
        lens_results = search_lens(ing, lens_api_key)
        all_hits += lens_results
    
    if not all_hits:
        print("No patents found")
        return pd.DataFrame()
    
    df = pd.DataFrame(all_hits)
    
    df = df.drop_duplicates(subset=['publication_number'], keep='first')
    
    df = df.reset_index(drop=True)
    
    print(f"Total unique patents: {len(df)}")
    
    return df
