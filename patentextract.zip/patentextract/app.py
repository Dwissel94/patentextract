from flask import Flask, render_template, request, send_file
import io
import os
from rld_extractor import run_extraction

app = Flask(__name__)
last_df = None

@app.after_request
def add_header(response):
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

@app.route("/", methods=["GET", "POST"])
def index():
    global last_df
    results = None
    query = ""
    error_msg = None
    
    if request.method == "POST":
        query = request.form.get("query", "").strip()
        lens_key = request.form.get("lens_key", "").strip()
        
        if not lens_key:
            lens_key = os.environ.get("LENS_API_KEY")
        
        if not query:
            error_msg = "Please enter a drug name or INN."
        else:
            try:
                print(f"Searching for: {query}")
                df = run_extraction(query, lens_key or None)
                if df is None or df.empty:
                    error_msg = "No patents found. Try another drug name, or the database might be temporarily unavailable."
                else:
                    results = df.to_dict(orient="records")
                    last_df = df
                    print(f"Found {len(results)} results")
            except Exception as e:
                print(f"Error during search: {e}")
                import traceback
                traceback.print_exc()
                error_msg = f"Error while searching: {str(e)}. Please try again or contact support."
    
    return render_template("index.html", results=results, query=query, error_msg=error_msg)

@app.route("/download")
def download():
    global last_df
    if last_df is None:
        return "No data to download", 400
    
    buf = io.BytesIO()
    last_df.to_excel(buf, index=False)
    buf.seek(0)
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="rld_patents.xlsx"
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
