from flask import Flask, render_template, request, send_file, redirect, url_for, session
import io
import os
from rld_extractor import run_extraction

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "medis-patent-extractor-secret-key-2025")
last_df = None

@app.after_request
def add_header(response):
    response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response.headers['Pragma'] = 'no-cache'
    response.headers['Expires'] = '0'
    return response

def get_api_key_preview():
    """Get a masked preview of the API key"""
    api_key = session.get('lens_api_key') or os.environ.get("LENS_API_KEY")
    if api_key and len(api_key) > 8:
        return f"{api_key[:4]}{'*' * (len(api_key) - 8)}{api_key[-4:]}"
    elif api_key:
        return '*' * len(api_key)
    return ""

@app.route("/", methods=["GET", "POST"])
def index():
    global last_df
    results = None
    query = ""
    error_msg = None
    api_key_preview = get_api_key_preview()
    api_key_status = session.pop('api_key_status', None)
    
    if request.method == "POST":
        query = request.form.get("query", "").strip()
        
        if not query:
            error_msg = "Please enter a drug name or INN."
        else:
            try:
                print(f"Searching for: {query}")
                df = run_extraction(query)
                if df is None or df.empty:
                    error_msg = "No patents found. Try another drug name, or the database might be temporarily unavailable."
                else:
                    results = df.to_dict(orient="records")
                    last_df = df
                    print(f"Found {len(results)} results")
            except Exception as e:
                print(f"Error during search: {e}")
                import traceback
                traceback.print_exc()
                error_msg = f"Error while searching: {str(e)}. Please try again or contact support."
    
    return render_template("index.html", results=results, query=query, error_msg=error_msg, 
                         api_key_preview=api_key_preview, api_key_status=api_key_status)

@app.route("/update_api_key", methods=["POST"])
def update_api_key():
    lens_api_key = request.form.get("lens_api_key", "").strip()
    
    if lens_api_key:
        session['lens_api_key'] = lens_api_key
        os.environ["LENS_API_KEY"] = lens_api_key
        session['api_key_status'] = {
            'type': 'success',
            'message': 'API key updated successfully! You can now search for patents.'
        }
        print("API key updated successfully")
    else:
        current_key = session.get('lens_api_key') or os.environ.get("LENS_API_KEY")
        if current_key:
            session['api_key_status'] = {
                'type': 'info',
                'message': 'No changes made. Current API key is still active.'
            }
        else:
            session['api_key_status'] = {
                'type': 'warning',
                'message': 'Please enter a valid API key.'
            }
    
    return redirect(url_for('index'))

@app.route("/download")
def download():
    global last_df
    if last_df is None:
        return "No data to download", 400
    
    buf = io.BytesIO()
    last_df.to_excel(buf, index=False)
    buf.seek(0)
    return send_file(
        buf,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="rld_patents.xlsx"
    )

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
